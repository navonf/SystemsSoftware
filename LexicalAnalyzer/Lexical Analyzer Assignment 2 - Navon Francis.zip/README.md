# Lexical Analyzer
Scans in a PL/0 program and parses it for Lexical Analysis, identifying errors specified in the document.

- Have a file named "input.txt" in the same folder as LexicalAnalyzer.c

- Now, run the command below

$ gcc -o lex LexicalAnalyzer.c
$ ./lex

This will print out the Source Program, Lexeme Table, and Lexeme List.
