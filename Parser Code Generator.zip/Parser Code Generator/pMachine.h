#ifndef VM
#define VM

#include <stdio.h>
#include <stdlib.h>
#include <string.h>



// Function definitions
void pMachine();
void fetchCycle();
void executeCycle();
int base(int l, int base);

#endif
